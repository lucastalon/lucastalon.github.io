# Akhil Lochen — Product Design Portfolio

This repo contains the code that powers my product design portfolio website.

Had a lot of fun building this website. Taking a project from an idea into Figma, then bringing it to life with code has got to be one of the most satisfying experiences ever! Also, learnt the basics of CSS animations during this project (shout-out to Stack Overflow & YouTube). 

🔗 [Click here](https://akhillochen.github.io/product-design-portfolio/website) to check out the latest version of the site.

![Akhil Lochen — Product Designer](https://github.com/akhillochen/product-design-portfolio/blob/master/website/images/og-img-akhil-lochen-portfolio.jpg?raw=true)
